package com.example.sijil;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    final int NAVY = Color.rgb(16,42,67), BLUE=Color.rgb(31,111,235), BG=Color.rgb(245,247,250);
    final int TEXT=Color.rgb(23,43,77), GREEN=Color.rgb(31,157,85), RED=Color.rgb(217,45,32);
    SharedPreferences prefs;
    ArrayList<Student>[] classes = new ArrayList[4];
    int currentClass = 0;
    LinearLayout root;

    static class Student {
        String name="";
        double[][] first = new double[2][5];   // month 1/2: daily1,daily2,daily3,activity,behavior
        double[][] second = new double[2][5];
        double notebook1=0, notebook2=0;
        double notebook3=0, notebook4=0;
        Student(String n){name=n;}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("grades",MODE_PRIVATE);
        load();
        for(int i=0;i<4;i++) if(classes[i]==null) classes[i]=new ArrayList<>();
        showHome();
    }

    TextView tv(String s,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setPadding(dp(14),dp(10),dp(14),dp(10)); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackgroundColor(BLUE); b.setPadding(dp(10),dp(8),dp(10),dp(8));
        return b;
    }
    EditText input(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setTextColor(TEXT); e.setHintTextColor(Color.GRAY);
        e.setGravity(Gravity.RIGHT); e.setPadding(dp(12),dp(8),dp(12),dp(8));
        e.setInputType(InputType.TYPE_CLASS_TEXT); return e;
    }
    EditText score(String hint,double val){
        EditText e=input(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if(val!=0) e.setText(String.valueOf(trim(val)));
        return e;
    }
    String trim(double v){ return v==Math.rint(v)?String.valueOf((int)v):String.valueOf(v); }
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(dp(10),dp(8),dp(10),dp(8));
        ScrollView sc=new ScrollView(this); sc.addView(root);
        setContentView(sc);
        TextView h=tv(title,24,Color.WHITE,true); h.setGravity(Gravity.CENTER); h.setBackgroundColor(NAVY);
        h.setPadding(dp(10),dp(16),dp(10),dp(16));
        root.addView(h,new LinearLayout.LayoutParams(-1,dp(68)));
    }

    void showHome(){
        base("سجل درجات الاجتماعيات");
        TextView sub=tv("للأستاذ أمير محمد",18,TEXT,true); sub.setGravity(Gravity.CENTER); root.addView(sub);
        TextView info=tv("سجل إلكتروني احترافي • 4 شعب • 50 طالب لكل شعبة",15,Color.DKGRAY,false); info.setGravity(Gravity.CENTER);
        root.addView(info);
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<4;i++){
            final int c=i; Button b=btn("الشعبة "+(i+1)+"   ("+classes[i].size()+"/50)");
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58)); p.setMargins(0,dp(6),0,dp(6));
            grid.addView(b,p); b.setOnClickListener(v->{currentClass=c; showClass();});
        }
        root.addView(grid);
        Button addAll=btn("➕ إضافة طالب إلى الشعبة الحالية");
        root.addView(addAll); addAll.setOnClickListener(v->{currentClass=0; showClass();});
        TextView note=tv("الحسابات: معدل الشهر = (يومي1 + يومي2 + يومي3 + النشاط + السلوك) ÷ 2، ومعدل الفصل = (الشهر الأول + الشهر الثاني) ÷ 2.",14,Color.DKGRAY,false);
        note.setPadding(dp(12),dp(25),dp(12),dp(10)); root.addView(note);
    }

    void showClass(){
        base("الشعبة "+(currentClass+1));
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button add=btn("➕ إضافة طالب"), print=btn("🖨 طباعة الشعبة");
        actions.addView(add,new LinearLayout.LayoutParams(0,dp(52),1));
        actions.addView(print,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(actions);
        add.setOnClickListener(v->addStudent());
        print.setOnClickListener(v->printClass());

        if(classes[currentClass].isEmpty()){
            TextView e=tv("لا يوجد طلاب بعد. أضف حتى 50 طالباً.",17,Color.GRAY,false); e.setGravity(Gravity.CENTER);
            root.addView(e);
        } else {
            for(int i=0;i<classes[currentClass].size();i++){
                final int idx=i; Student s=classes[currentClass].get(i);
                LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
                TextView name=tv((i+1)+". "+(s.name.isEmpty()?"طالب بدون اسم":s.name),17,TEXT,true);
                Button edit=btn("تحرير");
                row.addView(name,new LinearLayout.LayoutParams(0,dp(58),1)); row.addView(edit,new LinearLayout.LayoutParams(dp(95),dp(50)));
                row.setBackgroundColor(Color.WHITE);
                LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(62)); rp.setMargins(0,dp(4),0,dp(4)); root.addView(row,rp);
                edit.setOnClickListener(v->showStudent(idx));
            }
        }
        Button back=btn("↩ الرئيسية"); root.addView(back); back.setOnClickListener(v->showHome());
    }

    void addStudent(){
        if(classes[currentClass].size()>=50){Toast.makeText(this,"الشعبة مكتملة: 50 طالباً",Toast.LENGTH_SHORT).show();return;}
        final EditText e=input("اسم الطالب");
        new AlertDialog.Builder(this).setTitle("إضافة طالب").setView(e).setPositiveButton("حفظ",(d,w)->{
            String n=e.getText().toString().trim(); if(n.isEmpty()) n="طالب "+(classes[currentClass].size()+1);
            classes[currentClass].add(new Student(n)); save(); showClass();
        }).setNegativeButton("إلغاء",null).show();
    }

    TextView section(String title){
        TextView h=tv(title,19,Color.WHITE,true); h.setGravity(Gravity.CENTER); h.setBackgroundColor(BLUE);
        h.setPadding(dp(8),dp(10),dp(8),dp(10)); return h;
    }
    void showStudent(int idx){
        Student s=classes[currentClass].get(idx);
        base("تحرير الطالب — الشعبة "+(currentClass+1));
        EditText name=input("اسم الطالب"); name.setText(s.name); root.addView(name);
        root.addView(section("الفصل الأول"));
        EditText[][] a=new EditText[2][5];
        for(int m=0;m<2;m++){
            root.addView(tv("الشهر "+(m+1),17,TEXT,true));
            String[] labs={"اليومي 1 (20)","اليومي 2 (20)","اليومي 3 (20)","النشاط (20)","السلوك (20)"};
            for(int j=0;j<5;j++){ a[m][j]=score(labs[j],s.first[m][j]); root.addView(a[m][j]);}
            root.addView(tv("معدل الشهر "+(m+1)+": "+trim(monthAvg(s.first[m])),16,GREEN,true));
        }
        root.addView(tv("معدل الفصل الأول: "+trim(termAvg(s.first)),18,NAVY,true));
        root.addView(tv("الدفتر (الفصل الأول)",16,TEXT,true));
        EditText nb1=score("درجة الدفتر",s.notebook1); root.addView(nb1);

        root.addView(section("الفصل الثاني"));
        EditText[][] b=new EditText[2][5];
        for(int m=0;m<2;m++){
            root.addView(tv("الشهر "+(m+1),17,TEXT,true));
            String[] labs={"اليومي 1 (20)","اليومي 2 (20)","اليومي 3 (20)","النشاط (20)","السلوك (20)"};
            for(int j=0;j<5;j++){ b[m][j]=score(labs[j],s.second[m][j]); root.addView(b[m][j]);}
            root.addView(tv("معدل الشهر "+(m+1)+": "+trim(monthAvg(s.second[m])),16,GREEN,true));
        }
        root.addView(tv("معدل الفصل الثاني: "+trim(termAvg(s.second)),18,NAVY,true));
        root.addView(tv("الدفتر (الفصل الثاني)",16,TEXT,true));
        EditText nb2=score("درجة الدفتر",s.notebook2); root.addView(nb2);

        root.addView(section("نصف السنة والسعي السنوي"));
        TextView mid=tv("نصف السنة = الفصل الأول (يُحتسب حسب السجل)",17,TEXT,false); root.addView(mid);
        TextView annual=tv("السعي السنوي = (الفصل الأول + الفصل الثاني) ÷ 2",17,TEXT,false); root.addView(annual);
        Button save=btn("💾 حفظ النتائج"), del=btn("🗑 حذف الطالب");
        root.addView(save); root.addView(del);
        save.setOnClickListener(v->{
            s.name=name.getText().toString().trim();
            for(int m=0;m<2;m++) for(int j=0;j<5;j++) s.first[m][j]=read(a[m][j]);
            for(int m=0;m<2;m++) for(int j=0;j<5;j++) s.second[m][j]=read(b[m][j]);
            s.notebook1=read(nb1); s.notebook2=read(nb2);
            save(); Toast.makeText(this,"تم حفظ نتائج "+s.name,Toast.LENGTH_SHORT).show(); showClass();
        });
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الطالب؟").setMessage("سيتم حذف الطالب ودرجاته.")
                .setPositiveButton("حذف",(d,w)->{classes[currentClass].remove(idx);save();showClass();})
                .setNegativeButton("إلغاء",null).show());
    }

    double read(EditText e){try{double v=Double.parseDouble(e.getText().toString().trim());return Math.max(0,Math.min(20,v));}catch(Exception x){return 0;}}
    double monthAvg(double[] x){double sum=0;for(double v:x)sum+=v;return sum/2.0;}
    double termAvg(double[][] x){return (monthAvg(x[0])+monthAvg(x[1]))/2.0;}
    double annual(Student s){return (termAvg(s.first)+termAvg(s.second))/2.0;}

    void printClass(){
        final String html=buildHtml();
        WebViewPrintAdapter adapter=new WebViewPrintAdapter(this,html);
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print("سجل درجات الاجتماعيات - الشعبة "+(currentClass+1),adapter,new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME).build());
    }

    String buildHtml(){
        StringBuilder h=new StringBuilder();
        h.append("<html dir='rtl'><head><meta charset='utf-8'><style>")
         .append("body{font-family:sans-serif;font-size:10px}h1,h2{text-align:center}table{border-collapse:collapse;width:100%}")
         .append("th,td{border:1px solid #333;padding:4px;text-align:center}th{background:#eee}")
         .append("</style></head><body><h1>سجل درجات الاجتماعيات</h1><h2>للأستاذ أمير محمد — الشعبة ")
         .append(currentClass+1).append("</h2><table><tr><th>ت</th><th>اسم الطالب</th>")
         .append("<th>ف1 يومي1</th><th>يومي2</th><th>يومي3</th><th>نشاط</th><th>سلوك</th><th>شهر1</th>")
         .append("<th>شهر2</th><th>معدل ف1</th><th>دفتر1</th>")
         .append("<th>ف2 يومي1</th><th>يومي2</th><th>يومي3</th><th>نشاط</th><th>سلوك</th><th>شهر1</th><th>شهر2</th><th>معدل ف2</th><th>دفتر2</th><th>السعي السنوي</th></tr>");
        for(int i=0;i<classes[currentClass].size();i++){
            Student s=classes[currentClass].get(i);
            h.append("<tr><td>").append(i+1).append("</td><td>").append(esc(s.name)).append("</td>");
            for(double v:s.first[0])h.append("<td>").append(trim(v)).append("</td>");
            h.append("<td>").append(trim(monthAvg(s.first[0])).append("</td>"));
            h.append("<td>").append(trim(monthAvg(s.first[1])).append("</td>"));
            h.append("<td>").append(trim(termAvg(s.first))).append("</td><td>").append(trim(s.notebook1)).append("</td>");
            for(double v:s.second[0])h.append("<td>").append(trim(v)).append("</td>");
            h.append("<td>").append(trim(monthAvg(s.second[0])).append("</td>"));
            h.append("<td>").append(trim(monthAvg(s.second[1])).append("</td>"));
            h.append("<td>").append(trim(termAvg(s.second))).append("</td><td>").append(trim(s.notebook2)).append("</td>");
            h.append("<td>").append(trim(annual(s))).append("</td></tr>");
        }
        return h.append("</table></body></html>").toString();
    }
    String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}

    void save(){
        JSONArray all=new JSONArray();
        try{
            for(int c=0;c<4;c++){
                JSONArray arr=new JSONArray();
                for(Student s:classes[c]){
                    JSONObject o=new JSONObject();o.put("name",s.name);
                    JSONArray f=new JSONArray(),q=new JSONArray();
                    for(int m=0;m<2;m++){JSONArray r=new JSONArray();for(int j=0;j<5;j++)r.put(s.first[m][j]);f.put(r);}
                    for(int m=0;m<2;m++){JSONArray r=new JSONArray();for(int j=0;j<5;j++)r.put(s.second[m][j]);q.put(r);}
                    o.put("first",f);o.put("second",q);o.put("nb1",s.notebook1);o.put("nb2",s.notebook2);arr.put(o);
                } all.put(arr);
            }
            prefs.edit().putString("data",all.toString()).apply();
        }catch(Exception e){}
    }
    void load(){
        for(int i=0;i<4;i++)classes[i]=new ArrayList<>();
        try{
            JSONArray all=new JSONArray(prefs.getString("data","[]"));
            for(int c=0;c<Math.min(4,all.length());c++){
                JSONArray arr=all.getJSONArray(c);
                for(int k=0;k<arr.length();k++){
                    JSONObject o=arr.getJSONObject(k);Student s=new Student(o.optString("name",""));
                    JSONArray f=o.optJSONArray("first"),q=o.optJSONArray("second");
                    if(f!=null)for(int m=0;m<2;m++)for(int j=0;j<5;j++)s.first[m][j]=f.getJSONArray(m).optDouble(j,0);
                    if(q!=null)for(int m=0;m<2;m++)for(int j=0;j<5;j++)s.second[m][j]=q.getJSONArray(m).optDouble(j,0);
                    s.notebook1=o.optDouble("nb1",0);s.notebook2=o.optDouble("nb2",0);classes[c].add(s);
                }
            }
        }catch(Exception e){}
    }

    static class WebViewPrintAdapter extends PrintDocumentAdapter {
        Activity a; String html; android.webkit.WebView w;
        WebViewPrintAdapter(Activity a,String html){this.a=a;this.html=html;}
        @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,android.print.PageRange[] p,android.os.CancellationSignal cs,android.print.PrintDocumentAdapter.LayoutResultCallback cb,android.os.Bundle b){
            w=new android.webkit.WebView(a); w.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);
            new android.os.Handler().postDelayed(()->{
                PrintDocumentAdapter.WriteResultCallback dummy=null;
                android.print.PrintDocumentInfo info=new android.print.PrintDocumentInfo.Builder("grades.pdf").setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build();
                cb.onLayoutFinished(info,true);
            },500);
        }
        @Override public void onWrite(android.print.PageRange[] pages,android.os.ParcelFileDescriptor fd,android.os.CancellationSignal cs,android.print.PrintDocumentAdapter.WriteResultCallback cb){
            w.createPrintDocumentAdapter("grades").onWrite(pages,fd,cs,cb);
        }
    }
}
