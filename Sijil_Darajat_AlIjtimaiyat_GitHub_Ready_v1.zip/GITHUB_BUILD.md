# بناء APK عبر GitHub Actions

1. ارفع محتويات هذا المجلد إلى Repository جديد في GitHub.
2. افتح تبويب Actions.
3. اختر **Build Android APK** ثم **Run workflow**.
4. بعد اكتمال البناء، افتح نتيجة التشغيل وانزل إلى **Artifacts**.
5. نزّل `Sijil-Darajat-AlIjtimaiyat-debug` وفك الضغط لتحصل على APK.

ملاحظة: يحتاج المشروع إلى Gradle Wrapper (`gradlew` ومجلد `gradle/wrapper`) لكي يعمل البناء مباشرة. إذا لم تكن هذه الملفات موجودة في المشروع، افتح المشروع مرة واحدة في بيئة Android/Gradle وأنشئ الـwrapper، أو أخبر ChatGPT ليجهز لك نسخة تعتمد على إعداد بناء مختلف.
