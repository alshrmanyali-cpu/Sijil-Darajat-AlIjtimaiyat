package com.example.sijil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Student(
    val name: String,
    val daily: Int = 0,
    val monthly: Int = 0,
    val mid: Int = 0
) {
    val average: Int get() = (daily + monthly + mid) / 3
    val result: String get() = if (average >= 50) "ناجح" else "راسب"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    var students by remember { mutableStateOf(listOf<Student>()) }
    var name by remember { mutableStateOf("") }
    var daily by remember { mutableStateOf("") }
    var monthly by remember { mutableStateOf("") }
    var mid by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("سجل درجات الاجتماعيات") }) },
                floatingActionButton = {
                    FloatingActionButton(onClick = { showAdd = true }) { Text("+", fontSize = 24.sp) }
                }
            ) { padding ->
                Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("وزارة التربية العراقية", style = MaterialTheme.typography.titleMedium)
                    Text("المادة: الاجتماعيات", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("عدد الطلاب: ${students.size}")
                    Spacer(Modifier.height(12.dp))
                    if (students.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("لا توجد أسماء بعد\nاضغط + لإضافة طالب", textAlign = TextAlign.Center)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(students) { s ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(s.name, style = MaterialTheme.typography.titleMedium)
                                        Text("اليومي: ${s.daily}   الشهري: ${s.monthly}   نصف السنة: ${s.mid}")
                                        Text("المعدل: ${s.average} — ${s.result}")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (showAdd) {
                AlertDialog(
                    onDismissRequest = { showAdd = false },
                    title = { Text("إضافة طالب") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(name, { name = it }, label = { Text("اسم الطالب") })
                            OutlinedTextField(daily, { daily = it.filter(Char::isDigit).take(3) }, label = { Text("درجة اليومي") })
                            OutlinedTextField(monthly, { monthly = it.filter(Char::isDigit).take(3) }, label = { Text("درجة الشهري") })
                            OutlinedTextField(mid, { mid = it.filter(Char::isDigit).take(3) }, label = { Text("نصف السنة") })
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (name.isNotBlank()) {
                                students = students + Student(name, daily.toIntOrNull() ?: 0, monthly.toIntOrNull() ?: 0, mid.toIntOrNull() ?: 0)
                                name = ""; daily = ""; monthly = ""; mid = ""; showAdd = false
                            }
                        }) { Text("حفظ") }
                    },
                    dismissButton = { TextButton(onClick = { showAdd = false }) { Text("إلغاء") } }
                )
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
