package com.example.sijil;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.os.ParcelFileDescriptor;
import android.print.PrintManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    static final int SECTIONS = 4, STUDENTS = 50;
    final Student[][] data = new Student[SECTIONS][STUDENTS];
    SharedPreferences prefs;
    int currentSection = 0;
    final int NAVY = Color.rgb(8,40,74), BLUE = Color.rgb(25,118,210),
            GREEN = Color.rgb(32,145,92), GOLD = Color.rgb(217,164,65),
            BG = Color.rgb(245,248,252);

    static class Term {
        double month1, d11, d12, d13, activity1, behavior1;
        double month2, d21, d22, d23, activity2, behavior2;
        double halfYear;
        double month1Avg() { return (month1+d11+d12+d13+activity1+behavior1)/2.0; }
        double month2Avg() { return (month2+d21+d22+d23+activity2+behavior2)/2.0; }
        double average() { return (month1Avg()+month2Avg())/2.0; }
    }
    static class Student {
        String name = "";
        Term first = new Term();
        Term second = new Term();
        double annual() { return (first.average()+first.halfYear+second.average())/3.0; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("grades", MODE_PRIVATE);
        for(int s=0;s<SECTIONS;s++) for(int i=0;i<STUDENTS;i++) data[s][i]=new Student();
        load();
        home();
    }

    int dp(int n){ return Math.round(n*getResources().getDisplayMetrics().density); }
    String f(double x){ return String.format(Locale.US,"%.2f",x).replaceAll("0+$","").replaceAll("\\.$",""); }

    LinearLayout root(){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setBackgroundColor(BG);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }
    TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    Button btn(String s, View.OnClickListener c){
        Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setAllCaps(false); b.setOnClickListener(c); return b;
    }
    LinearLayout header(String title){
        LinearLayout h=root(); h.setBackgroundColor(NAVY);
        TextView t=text(title,20,Color.WHITE); h.addView(t,new LinearLayout.LayoutParams(-1,dp(62)));
        return h;
    }
    EditText input(String hint,String value,int max){
        EditText e=new EditText(this); e.setHint(hint); e.setText(value);
        e.setTextSize(17); e.setGravity(Gravity.RIGHT);
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(10),dp(5),dp(10),dp(5));
        e.setTag(max); return e;
    }
    EditText nameInput(String hint,String value){
        EditText e=new EditText(this); e.setHint(hint); e.setText(value); e.setTextSize(18);
        e.setGravity(Gravity.RIGHT); e.setInputType(InputType.TYPE_CLASS_TEXT); return e;
    }
    void home(){
        LinearLayout r=root(); r.addView(header("سجل درجات الاجتماعيات\nللأستاذ أمير محمد"));
        ScrollView sv=new ScrollView(this); LinearLayout box=root(); box.setPadding(dp(14),dp(14),dp(14),dp(20));
        box.addView(text("السجل الرئيسي",24,NAVY));
        for(int s=0;s<4;s++){
            Button b=btn("الشعبة "+(s+1)+"\n50 طالبًا",v->section(s));
            b.setTextColor(Color.WHITE); b.setBackgroundColor(s%2==0?BLUE:GREEN);
            box.addView(b,new LinearLayout.LayoutParams(-1,dp(78)));
        }
        box.addView(btn("👥 إضافة وتعديل أسماء الطلاب",v->manager()));
        box.addView(btn("🖨 التقارير والطباعة حسب الشعبة",v->reports()));
        box.addView(text("حفظ تلقائي • 4 شعب • 50 طالبًا لكل شعبة • 200 طالب",14,Color.GRAY));
        sv.addView(box); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(r);
    }
    void section(int sec){
        currentSection=sec; LinearLayout r=root(); r.addView(header("الشعبة "+(sec+1)+" — 50 طالبًا"));
        EditText search=nameInput("ابحث عن اسم الطالب","");
        r.addView(search,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout list=root(); list.setPadding(dp(8),dp(5),dp(8),dp(10));
        Runnable refresh=()->{
            list.removeAllViews(); String q=search.getText().toString().trim();
            for(int i=0;i<STUDENTS;i++){
                Student st=data[sec][i]; String nm=st.name.isEmpty()?"طالب رقم "+(i+1):st.name;
                if(q.isEmpty()||nm.contains(q)){
                    Button b=btn((i+1)+". "+nm+"\nف1: "+f(st.first.average())+"   نصف: "+f(st.first.halfYear)+"   ف2: "+f(st.second.average())+"   سنوي: "+f(st.annual()),v->student(sec,i));
                    b.setGravity(Gravity.RIGHT); list.addView(b,new LinearLayout.LayoutParams(-1,dp(78)));
                }
            }
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();} public void afterTextChanged(Editable e){}});
        refresh.run(); ScrollView sv=new ScrollView(this); sv.addView(list); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=root(); bar.addView(btn("الرئيسية",v->home()),new LinearLayout.LayoutParams(0,dp(56),1)); bar.addView(btn("طباعة",v->report(sec)),new LinearLayout.LayoutParams(0,dp(56),1)); r.addView(bar); setContentView(r);
    }
    void manager(){
        LinearLayout r=root(); r.addView(header("إضافة وتعديل أسماء الطلاب"));
        ScrollView sv=new ScrollView(this); LinearLayout box=root(); box.setPadding(dp(10),dp(10),dp(10),dp(20));
        for(int s=0;s<4;s++){ box.addView(text("الشعبة "+(s+1),19,BLUE));
            for(int i=0;i<STUDENTS;i++){ EditText e=nameInput("الطالب "+(i+1),data[s][i].name); e.setTag(new int[]{s,i}); box.addView(e,new LinearLayout.LayoutParams(-1,dp(52))); }
        }
        box.addView(btn("💾 حفظ جميع الأسماء",v->{
            for(int x=0;x<box.getChildCount();x++){View z=box.getChildAt(x); if(z instanceof EditText){int[] a=(int[])z.getTag(); if(a!=null)data[a[0]][a[1]].name=((EditText)z).getText().toString().trim();}}
            save(); Toast.makeText(this,"تم حفظ الأسماء",Toast.LENGTH_SHORT).show();
        }));
        sv.addView(box); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); r.addView(btn("رجوع",v->home()),new LinearLayout.LayoutParams(-1,dp(56))); setContentView(r);
    }
    EditText grade(String label,double value,double max,Runnable changed){
        EditText e=input(label+" (حد أعلى "+f(max)+")",value==0?"":f(value),(int)max);
        e.setOnFocusChangeListener((v,has)->{if(!has){double x=num(e.getText().toString()); if(x<0)x=0;if(x>max)x=max;e.setText(x==0?"":f(x));changed.run();save();}});
        return e;
    }
    double num(String s){try{return Double.parseDouble(s.replace(',','.'));}catch(Exception e){return 0;}}

    void termUI(LinearLayout box,String title,Term t,boolean first){
        box.addView(text(title,21,NAVY));
        EditText m1=grade("درجة الشهر الأول",t.month1,100,()->t.month1=num(m1.getText().toString())); box.addView(m1);
        box.addView(text("اليومي والنشاط والسلوك — كل حقل من 20",14,BLUE));
        EditText a=grade("اليومي 1",t.d11,20,()->t.d11=num(a.getText().toString())); box.addView(a);
        EditText b=grade("اليومي 2",t.d12,20,()->t.d12=num(b.getText().toString())); box.addView(b);
        EditText c=grade("اليومي 3",t.d13,20,()->t.d13=num(c.getText().toString())); box.addView(c);
        EditText d=grade("النشاط",t.activity1,20,()->t.activity1=num(d.getText().toString())); box.addView(d);
        EditText e=grade("السلوك",t.behavior1,20,()->t.behavior1=num(e.getText().toString())); box.addView(e);
        box.addView(text("معدل الشهر الأول = (درجة الشهر + اليوميات + النشاط + السلوك) ÷ 2 = "+f(t.month1Avg())+" / 100",16,GREEN));
        EditText m2=grade("درجة الشهر الثاني",t.month2,100,()->t.month2=num(m2.getText().toString())); box.addView(m2);
        box.addView(text("اليومي والنشاط والسلوك — كل حقل من 20",14,BLUE));
        EditText f1=grade("اليومي 1 للشهر الثاني",t.d21,20,()->t.d21=num(f1.getText().toString())); box.addView(f1);
        EditText f2=grade("اليومي 2 للشهر الثاني",t.d22,20,()->t.d22=num(f2.getText().toString())); box.addView(f2);
        EditText f3=grade("اليومي 3 للشهر الثاني",t.d23,20,()->t.d23=num(f3.getText().toString())); box.addView(f3);
        EditText fa=grade("النشاط للشهر الثاني",t.activity2,20,()->t.activity2=num(fa.getText().toString())); box.addView(fa);
        EditText fb=grade("السلوك للشهر الثاني",t.behavior2,20,()->t.behavior2=num(fb.getText().toString())); box.addView(fb);
        box.addView(text("معدل الشهر الثاني = (درجة الشهر + اليوميات + النشاط + السلوك) ÷ 2 = "+f(t.month2Avg())+" / 100",16,GREEN));
        box.addView(text("⭐ معدل "+title+" = (معدل الشهر الأول + معدل الشهر الثاني) ÷ 2 = "+f(t.average())+" / 100",20,NAVY));
    }

    void student(int sec,int idx){
        Student st=data[sec][idx]; LinearLayout r=root(); r.addView(header("تفاصيل الطالب رقم "+(idx+1)));
        ScrollView sv=new ScrollView(this); LinearLayout box=root(); box.setPadding(dp(10),dp(10),dp(10),dp(24));
        EditText nm=nameInput("اسم الطالب",st.name); box.addView(nm,new LinearLayout.LayoutParams(-1,dp(58)));
        termUI(box,"الفصل الأول",st.first,true);
        EditText mid=grade("نصف السنة",st.first.halfYear,100,()->st.first.halfYear=num(mid.getText().toString())); box.addView(mid);
        box.addView(text("درجة نصف السنة: "+f(st.first.halfYear)+" / 100",18,NAVY));
        termUI(box,"الفصل الثاني",st.second,false);
        box.addView(text("السعي السنوي = (معدل الفصل الأول + نصف السنة + معدل الفصل الثاني) ÷ 3 = "+f(st.annual())+" / 100",21,GOLD));
        box.addView(btn("💾 حفظ الطالب",v->{st.name=nm.getText().toString().trim();save();Toast.makeText(this,"تم الحفظ",Toast.LENGTH_SHORT).show();section(sec);}));
        sv.addView(box); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); r.addView(btn("رجوع للشعبة",v->section(sec)),new LinearLayout.LayoutParams(-1,dp(56))); setContentView(r);
    }

    void reports(){
        LinearLayout r=root(); r.addView(header("التقارير والطباعة"));
        LinearLayout box=root(); box.setPadding(dp(15),dp(20),dp(15),dp(20));
        box.addView(text("اختر الشعبة",21,NAVY));
        for(int s=0;s<4;s++) box.addView(btn("🖨 طباعة جدول الشعبة "+(s+1)+" — 50 طالبًا",v->report(s)));
        r.addView(box,new LinearLayout.LayoutParams(-1,0,1)); r.addView(btn("الرئيسية",v->home()),new LinearLayout.LayoutParams(-1,dp(56))); setContentView(r);
    }

    void report(int sec){
        LinearLayout r=root(); r.addView(header("معاينة تقرير الشعبة "+(sec+1)));
        TableLayout table=new TableLayout(this); table.setStretchAllColumns(true); table.setBackgroundColor(Color.WHITE);
        String[] h={"ت","اسم الطالب","ف1 ي1","ف1 ي2","ف1 ي3","نشاط","سلوك","ش1","م1","ش2","م2","معدل ف1","نصف","معدل ف2","السعي"};
        row(table,h,true);
        for(int i=0;i<STUDENTS;i++){Student s=data[sec][i];Term g=s.first;String[] v={""+(i+1),s.name.isEmpty()?"طالب "+(i+1):s.name,f(g.d11),f(g.d12),f(g.d13),f(g.activity1),f(g.behavior1),f(g.month1),f(g.month1Avg()),f(g.month2),f(g.month2Avg()),f(g.average()),f(g.halfYear),f(s.second.average()),f(s.annual())};row(table,v,false);}
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.addView(table); r.addView(hs,new LinearLayout.LayoutParams(-1,0,1));
        r.addView(btn("📄 طباعة / حفظ PDF",v->printSection(sec)),new LinearLayout.LayoutParams(-1,dp(58)));
        r.addView(btn("رجوع",v->reports()),new LinearLayout.LayoutParams(-1,dp(54))); setContentView(r);
    }
    void row(TableLayout t,String[] vals,boolean head){
        TableRow tr=new TableRow(this);
        for(String v:vals){TextView x=text(v,head?11:10,head?Color.WHITE:Color.DKGRAY);x.setBackgroundColor(head?NAVY:Color.WHITE);x.setGravity(Gravity.CENTER);tr.addView(x,new TableRow.LayoutParams(dp(82),dp(50)));}
        t.addView(tr);
    }

    void printSection(int sec){
        PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
        pm.print("سجل درجات الشعبة "+(sec+1),new ReportAdapter(this,sec),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());
    }

    class ReportAdapter extends PrintDocumentAdapter {
        Context ctx; int sec; PdfDocument doc;
        ReportAdapter(Context c,int s){ctx=c;sec=s;}
        public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal sig,LayoutResultCallback cb,Bundle extras){
            doc=new PdfDocument();
            cb.onLayoutFinished(new PrintDocumentInfo.Builder("سجل_درجات_الشعبة_"+(sec+1)+".pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true);
        }
        public void onWrite(PageRange[] pages,ParcelFileDescriptor fd,CancellationSignal sig,WriteResultCallback cb){
            PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(1600,1100,1).create());
            Canvas c=page.getCanvas(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE);c.drawColor(Color.WHITE);p.setColor(NAVY);p.setTextSize(30);p.setTypeface(Paint.create(Typeface.DEFAULT,Typeface.BOLD));
            c.drawText("سجل درجات الاجتماعيات - الأستاذ أمير محمد",900,45,p);p.setTextSize(20);c.drawText("الشعبة "+(sec+1)+" - 50 طالبًا",1280,78,p);
            String[] h={"ت","اسم الطالب","ي1","ي2","ي3","نشاط","سلوك","ش1","م1","ش2","م2","ف1","نصف","ف2","السعي"};
            float[] w={35,190,70,70,70,70,70,70,70,70,70,80,80,80,80};float x=1520,y=105;p.setTextSize(13);
            for(int i=0;i<h.length;i++){x-=w[i];p.setColor(NAVY);c.drawRect(x,y,x+w[i],y+35,p);p.setColor(Color.WHITE);c.drawText(h[i],x+5,y+23,p);}
            y+=35;p.setTextSize(11);
            for(int i=0;i<STUDENTS;i++){if(y>1050)break;Student s=data[sec][i];Term g=s.first;String[] v={""+(i+1),s.name.isEmpty()?"طالب "+(i+1):s.name,f(g.d11),f(g.d12),f(g.d13),f(g.activity1),f(g.behavior1),f(g.month1),f(g.month1Avg()),f(g.month2),f(g.month2Avg()),f(g.average()),f(g.halfYear),f(s.second.average()),f(s.annual())};x=1520;for(int j=0;j<v.length;j++){x-=w[j];p.setColor(i%2==0?Color.rgb(245,248,252):Color.WHITE);c.drawRect(x,y,x+w[j],y+28,p);p.setColor(Color.DKGRAY);c.drawText(v[j].length()>18?v[j].substring(0,18):v[j],x+3,y+19,p);}y+=28;}
            doc.finishPage(page);try{doc.writeTo(new java.io.FileOutputStream(fd.getFileDescriptor()));cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}finally{doc.close();}
        }
    }

    void save(){
        SharedPreferences.Editor e=prefs.edit();
        for(int s=0;s<SECTIONS;s++)for(int i=0;i<STUDENTS;i++){Student st=data[s][i];String k=s+"_"+i+"_";e.putString(k+"n",st.name);double[] v={st.first.month1,st.first.d11,st.first.d12,st.first.d13,st.first.activity1,st.first.behavior1,st.first.month2,st.first.d21,st.first.d22,st.first.d23,st.first.activity2,st.first.behavior2,st.first.halfYear,st.second.month1,st.second.d11,st.second.d12,st.second.d13,st.second.activity1,st.second.behavior1,st.second.month2,st.second.d21,st.second.d22,st.second.d23,st.second.activity2,st.second.behavior2,st.second.halfYear};for(int j=0;j<v.length;j++)e.putString(k+"g"+j,""+v[j]);}e.apply();
    }
    void load(){
        for(int s=0;s<SECTIONS;s++)for(int i=0;i<STUDENTS;i++){Student st=data[s][i];String k=s+"_"+i+"_";st.name=prefs.getString(k+"n","");double[] v=new double[26];for(int j=0;j<26;j++)v[j]=num(prefs.getString(k+"g"+j,"0"));st.first=term(v,0);st.second=term(v,13);}
    }
    Term term(double[] v,int o){Term t=new Term();t.month1=v[o];t.d11=v[o+1];t.d12=v[o+2];t.d13=v[o+3];t.activity1=v[o+4];t.behavior1=v[o+5];t.month2=v[o+6];t.d21=v[o+7];t.d22=v[o+8];t.d23=v[o+9];t.activity2=v[o+10];t.behavior2=v[o+11];t.halfYear=v[o+12];return t;}
    @Override public void onBackPressed(){home();}
}
